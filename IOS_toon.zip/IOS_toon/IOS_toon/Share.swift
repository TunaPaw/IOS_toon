//
//  Share.swift
//  IOS_toon
//
//  Created by YOUNG on 2021/02/18.
//

import Foundation

struct Share{
    static var userID: String = ""
}
